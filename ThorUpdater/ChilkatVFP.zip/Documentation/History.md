
## History

## Version 1.0
*Released 09/18/2022*

This is the first release (1.0) of ChilkatVFP.

